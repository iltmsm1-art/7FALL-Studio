SevenFall Studio Edition v1.3

Sprint 1.1: mobile play order, phase indicator, Fate Row proximity, Session Stats after Last Score, and Draw -> Discard -> Score flow.
