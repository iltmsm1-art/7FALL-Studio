# SevenFall Studio Edition v1.8 Icon + PWA Polish

Upload/replace these files in GitHub:

- index.html
- manifest.webmanifest
- service-worker.js
- _headers
- netlify.toml
- icons/favicon-16x16.png
- icons/favicon-32x32.png
- icons/apple-touch-icon.png
- icons/android-chrome-192x192.png
- icons/android-chrome-512x512.png

After Netlify publishes, remove the old SevenFall icon from Android/iPhone home screen and add it again if the icon does not update automatically.
